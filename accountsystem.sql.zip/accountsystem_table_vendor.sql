
-- --------------------------------------------------------

--
-- Table structure for table `vendor`
--

CREATE TABLE `vendor` (
  `Vid` int(11) NOT NULL,
  `Vname` varchar(300) DEFAULT NULL,
  `Vaddress` varchar(150) DEFAULT NULL,
  `Vphone` int(11) DEFAULT NULL,
  `Vemail` varchar(50) DEFAULT NULL,
  `Vbankd` varchar(100) DEFAULT NULL,
  `Vpan` varchar(10) DEFAULT NULL,
  `Vgst` int(15) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `vendor`
--

INSERT INTO `vendor` (`Vid`, `Vname`, `Vaddress`, `Vphone`, `Vemail`, `Vbankd`, `Vpan`, `Vgst`) VALUES
(89, 'fdgfdgfdg', 'dsfds', 852, 'sadsad', '86543', 'sadasdasda', 85121),
(85855, 'tgfrdfsdfg', 'asdffggh', 7854, 'sdfgg', '8754', 'sdfgh', 7854),
(85858, 'tgfrdfsdfg', 'asdffggh', 7854, 'sdfgg', '8754', 'sdfgh', 7854);
