
-- --------------------------------------------------------

--
-- Table structure for table `product`
--

CREATE TABLE `product` (
  `Pid` int(11) NOT NULL,
  `Pname` varchar(50) DEFAULT NULL,
  `Pqnty` int(11) DEFAULT NULL,
  `Pprice` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `product`
--

INSERT INTO `product` (`Pid`, `Pname`, `Pqnty`, `Pprice`) VALUES
(7892, 'book', 200, 35);
