
-- --------------------------------------------------------

--
-- Table structure for table `transaction`
--

CREATE TABLE `transaction` (
  `Billid` int(11) NOT NULL,
  `Pname` varchar(100) DEFAULT NULL,
  `Preceiver` varchar(100) DEFAULT NULL,
  `Dateofissue` date DEFAULT NULL,
  `Qntyissue` int(11) DEFAULT NULL,
  `Tcost` int(11) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `transaction`
--

INSERT INTO `transaction` (`Billid`, `Pname`, `Preceiver`, `Dateofissue`, `Qntyissue`, `Tcost`) VALUES
(101, 'Books', 'Raj', '2020-10-06', 500, 6000);
