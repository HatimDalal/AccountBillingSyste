
-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `Uid` int(11) NOT NULL,
  `Uname` varchar(11) DEFAULT NULL,
  `Password` varchar(11) DEFAULT NULL,
  `Urole` char(1) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`Uid`, `Uname`, `Password`, `Urole`) VALUES
(105, 'jjaa', 'ytyvjasbkj', '0'),
(106, 'sfsdf', 'dfsdfsdfs', '0'),
(109, 'dassa', 'sadasda', '0');
